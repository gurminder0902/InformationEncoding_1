﻿using System;
using System.Linq;

namespace Encryption_assignment
{
    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Case:1-  Convert  String to Binary");
            Console.WriteLine("Case:2-  Convert  Binary to String");
            Console.WriteLine("Case:3-  Convert  String to Hexadecimal");
            Console.WriteLine("Case:4-  Convert  String to Base64");
            Console.WriteLine("Case:5-  Convert  Base64 to String");
            Console.WriteLine("Case:6-  Convert  Hexadecimal to String");
            Console.WriteLine("Case:7-  Encryption - Decryption");
            Console.WriteLine("Enter your choice");
            int caseSwitch = Convert.ToInt32(Console.ReadLine());

            switch (caseSwitch)
            {
                case 1:
                    Console.WriteLine("Enter Your Name: ");
                    String name = Console.ReadLine();
                    Console.WriteLine(Encrypter.StringToBinary_1(name));
                    break;
                case 2:
                    Console.WriteLine("Enter Binary value: ");
                    String name1 = Console.ReadLine();
                    Console.WriteLine(Encrypter.ConvertBinaryToString(name1));
                    break;
                case 3:
                    Console.WriteLine("Enter Your Name: ");
                    String name2 = Console.ReadLine();
                    Console.WriteLine(Encrypter.StringToHex2(name2));
                    break;
                case 4:
                    Console.WriteLine("Enter Your Name: ");
                    String name3 = Console.ReadLine();
                    Console.WriteLine(Encrypter.StringToBase64_1(name3));
                    break;
                case 5:
                    Console.WriteLine("Enter Base: ");
                    String name4 = Console.ReadLine();
                    Console.WriteLine(Encrypter.Base64ToString_1(name4));
                    break;

                case 6:
                    Console.WriteLine("Enter Hexadecimal Value: ");
                    String name5 = Console.ReadLine();
                    Console.WriteLine(Encrypter.HexToString(name5));
                    break;
                case 7:
                    Console.WriteLine("Enter your name: ");
                    String unicodeString = Console.ReadLine();
                
                    int[] cipher = new[] { 1, 1, 2, 3, 5, 8, 13 };                                                      //Fibonacci Series
                    string cipherasString = String.Join(",", cipher.Select(x => x.ToString()));                             //For display

                    int encryptionDepth = 20;

                    Encrypter encrypter = new Encrypter(unicodeString, cipher, encryptionDepth);

                   
                    string nameEncryptWithCipher = Encrypter.EncryptWithCipher(unicodeString, cipher);                       //Single Level Encrytion
                    Console.WriteLine($"Encrypted once using the cipher {{{cipherasString}}} {nameEncryptWithCipher}");

                    string nameDecryptWithCipher = Encrypter.DecryptWithCipher(nameEncryptWithCipher, cipher);
                    Console.WriteLine($"Decrypted once using the cipher {{{cipherasString}}} {nameDecryptWithCipher}");

             
                    string nameDeepEncryptWithCipher = Encrypter.DeepEncryptWithCipher(unicodeString, cipher, encryptionDepth);      //Deep Encrytion
                    Console.WriteLine($"Deep Encrypted {encryptionDepth} times using the cipher {{{cipherasString}}} {nameDeepEncryptWithCipher}");

                    string nameDeepDecryptWithCipher = Encrypter.DeepDecryptWithCipher(nameDeepEncryptWithCipher, cipher, encryptionDepth);
                    Console.WriteLine($"Deep Decrypted {encryptionDepth} times using the cipher {{{cipherasString}}} {nameDeepDecryptWithCipher}");

                    Console.WriteLine($"Base64 encoded {unicodeString} {encrypter.Base64}");                            //Base64 Encoded

                    string base64toPlainText = Encrypter.Base64ToString(encrypter.Base64);
                    Console.WriteLine($"Base64 decoded {encrypter.Base64} {base64toPlainText}");
                    break;
            }
        }
    }
    }

