﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
namespace Encryption_assignment

{
    class Encrypter
    { 
            public Encrypter(string originalText, int[] encryptionCipher = null, int encryptionDepth = 1)
            {
                OriginalText = originalText;

                if (encryptionCipher != null)
                {
                    if (EncryptionCipher != encryptionCipher)
                    {
                        EncryptionCipher = encryptionCipher;
                    }
                }

                if (EncryptionDepth != encryptionDepth)
                {
                    EncryptionDepth = encryptionDepth;
                }

                ConvertText(OriginalText, EncryptionCipher, EncryptionDepth);
            }

            public void ConvertText(string originalText, int[] encryptionCipher = null, int encryptionDepth = 1)
            {
                CipherEncrypted = DeepEncryptWithCipher(OriginalText, EncryptionCipher, EncryptionDepth);         //Cipher encrypt
                Base64 = StringToBase64(OriginalText);                                  //Convert Original data to differemt formats
                Binary = StringToBinary(OriginalText);
                Hexadecimal = StringToHex(OriginalText);
            }

            public string OriginalText { get; internal set; }
            public int[] EncryptionCipher { get; } = new[] { 1, 1, 2, 3, 5, 8 };                            //Fibonacci Series
            public int EncryptionDepth { get; } = 1;
            public string CipherEncrypted { get; internal set; }
            public string Base64 { get; internal set; }
            public string Binary { get; internal set; }
            public string Hexadecimal { get; internal set; }

            public static string DeepEncryptWithCipher(string originalText, int[] encryptionCipher, int encryptionDepth)
            {
                string result = originalText;
                for (int depth = 0; depth < encryptionDepth; depth++)
                {
                result = EncryptWithCipher(result, encryptionCipher);
                }
            return result;
            }
           
            public static string EncryptWithCipher(string text, int[] encryptionCipher)
            {
                if (encryptionCipher == null || encryptionCipher.Length == 0)
            {
                return text;
            }
            
            byte[] bytearray = Encoding.Unicode.GetBytes(text);
            byte[] bytearrayresult = bytearray;

            int encryptionCipherIndex = 0;
            for (int i = 0; i < bytearray.Length; i++)                              //Apply Encryption Cipher
            {
                encryptionCipherIndex = i;                                          //cipher index
                if (encryptionCipherIndex >= encryptionCipher.Length)
                {
                    
                    encryptionCipherIndex = 0;
                }
               
                if (bytearray[i] != 0)
                {
                    bytearrayresult[i] = (byte)(bytearray[i] + encryptionCipher[encryptionCipherIndex]);
                }
            }
            string newresult = Encoding.Unicode.GetString(bytearrayresult);
            return newresult;
            }
            public static string DeepDecryptWithCipher(string originalText, int[] encryptionCipher, int encryptionDepth)
            {
            string result = originalText;
            string[] encryptedValues = new string[encryptionDepth + 1];
            encryptedValues[0] = result;
            for (int depth = 0; depth < encryptionDepth; depth++)
            {
                result = DecryptWithCipher(result, encryptionCipher);
                encryptedValues[depth + 1] = result;
            }

            return result;
            }
            public static string DecryptWithCipher(string text, int[] encryptionCipher)               // Decrypts a cipher encrypted string
            {
            byte[] bytearray = Encoding.Unicode.GetBytes(text);
            byte[] bytearrayresult = bytearray;
            int encryptionCipherIndex = 0;
            for (int i = 0; i < bytearray.Length; i++)
            {            
                encryptionCipherIndex = i;
                if (encryptionCipherIndex >= encryptionCipher.Length)
                {

                    encryptionCipherIndex = 0;
                }

                if (bytearray[i] != 0)
                {
                    bytearrayresult[i] = (byte)(bytearray[i] - encryptionCipher[encryptionCipherIndex]);
                }
            }

            string newresult = Encoding.Unicode.GetString(bytearrayresult);

            return newresult;
            }

            public static string Base64ToString(string data)                    // Converts a Unicode Base64 string to decoded String
            {
            if (String.IsNullOrEmpty(data))
            {
                return String.Empty;
            }

            byte[] bytearray = Convert.FromBase64String(data);

            return Encoding.Unicode.GetString(bytearray);
            }
        
            public static string StringToBase64(string data)                       // Encodes a String to a Base64 String
            {
            byte[] bytearray = Encoding.Unicode.GetBytes(data);
            return Convert.ToBase64String(bytearray);
            }

            public static string StringToHex(string data)                           // A less mathmatical approach to ASCII to Hexadecimal conversion
            {
            StringBuilder sb = new StringBuilder();

            foreach (char c in data.ToCharArray())
            {
                sb.Append(Convert.ToString(c, 16).PadLeft(2, '0') + " ");
            }

            return sb.ToString().ToUpper();
            }

        
            public static string StringToBinary(string data)                        // A less mathmatical approach to ASCII to Binary conversion
            {
            StringBuilder sb = new StringBuilder();

            foreach (char c in data.ToCharArray())
            {
                
                sb.Append(Convert.ToString(c, 2).PadLeft(8, '0') + " ");        //Convert the char to base 2 and pad the output with 0
            }
            return sb.ToString();
            }
            public static string StringToBinary_1(string data)
            {
            StringBuilder sb = new StringBuilder();

            foreach (char c in data.ToCharArray())
            {
               
                sb.Append(Convert.ToString(c, 2).PadLeft(8, '0'));              //Convert the char to base 2 and pad the output with 0
            }
            return sb.ToString();
            }   
            public static string ConvertBinaryToString(string binaryString)
            {
            string output = "";
            for (int i = 0; i < binaryString.Length; i += 8)
            {
                string binaryOctet = binaryString.Substring(i, 8);
                output += ConvertToASCII(binaryOctet);

            }

            return (output);
            }   
            public static char ConvertToASCII(string binaryvalue)
            {
            string binaryOctet = binaryvalue;
            uint bytevalue = 0;
            int[] positionvalues = { 128, 64, 32, 16, 8, 4, 2, 1 };
            for (int c = 0; c < positionvalues.Length; c++)
            {
                string bit = binaryvalue.Substring(c, 1);
                bytevalue += bit == "1" ? (uint)positionvalues[c] : 0;
            }

            return ((char)bytevalue);
            }
            public static string StringToHex2(string data)
            {
            StringBuilder sb = new StringBuilder();

            byte[] bytearray = Encoding.ASCII.GetBytes(data);

            foreach (byte bytepart in bytearray)
            {
                sb.Append(bytepart.ToString("X2"));
            }

            return sb.ToString().ToUpper();
            }
            public static string StringToBase64_1(string data)
            {
            byte[] bytearray = Encoding.ASCII.GetBytes(data);

            string result = Convert.ToBase64String(bytearray);

            return result;
            }
            public static string Base64ToString_1(string base64String)
            {
            byte[] bytearray = Convert.FromBase64String(base64String);

            using (var ms = new MemoryStream(bytearray))
            {
                using (StreamReader reader = new StreamReader(ms))
                {
                    string text = reader.ReadToEnd();
                    return text;
                }
            }
            }
            public static string HexToString(string hexString)
            {
            if (hexString == null || (hexString.Length & 1) == 1)
            {
                throw new ArgumentException();
            }
            var sb = new StringBuilder();
            for (var i = 0; i < hexString.Length; i += 2)
            {
                var hexChar = hexString.Substring(i, 2);
                sb.Append((char)Convert.ToByte(hexChar, 16));
            }
            return sb.ToString();
    }

}

}
    

